#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 29 12:04:27 2018

@author: kamran
"""
import pandas as pd
import numpy as np
#from statistics import median

#For ignore the pandas warning
pd.options.mode.chained_assignment = None  # default='warn'
#For np warning run time
np.warnings.filterwarnings('ignore')

#thresh= 4.0
def is_outlier(column, thresh=4.0):
    """
    Returns a boolean array with True if points are outliers and False 
    otherwise.

    Parameters:
    -----------
        column: An numerical observations by num dimensions array of observations
        thresh : The modified z-score to use as a threshold. Observations with
            a modified z-score (based on the median absolute deviation) greater
            than this value will be classified as outliers.

    Returns:
    --------
        mask : A numerical observations-length boolean array.

    References:
    ----------
        Boris Iglewicz and David Hoaglin (1993), "Volume 16: How to Detect and
        Handle Outliers", The ASQC Basic References in Quality Control:
        Statistical Techniques, Edward F. Mykytka, Ph.D., Editor. 
    """
    if len(column.shape) == 1:
        column = column[:,None]
        #np.nanmedian(a)
    #median1 = median(column)
    median = np.nanmedian(column)
    #median = np.median(column, overwrite_input=True)
    #median = np.nanmedian(column, axis=0)
    diff = np.sum((column - median)**2, axis=-1)
    diff = np.sqrt(diff)
    med_abs_deviation = np.nanmedian(diff)

    modified_z_score = 0.6745 * diff / med_abs_deviation
        #if modified_z_score > thresh:
        

    return modified_z_score > thresh

# call_outlier is actuall function to call
# Taking df as argument and returning df with replacing outlier with nan
    

def call_outlier(df):
    for k in list(df.columns):
    #print(type((df[i][0])))
    #Checking if it is not string and unique values are not less than 10 for 
    # factor like features
        if not isinstance(df[k].iloc[0], str) and df[k].nunique() >= 10:
        #pass
            
            df[k] = df[k].astype(float)
            df[k][is_outlier(df[k].values)] = np.nan
            #print("It is a Integer:- ", k)
        #print(i)
        else:
            #pass
            continue
        #df[i][is_outlier(df[i].values)] = np.nan
        #print('\nIt is  a String:-', i)
        #print(i)
        
        
    return df


#Testing Part
"""
path = '/media/DATA/CVM/AutoML/poc_product_backorder' #Loacation of the all the files(i.e master script, all modules and all data files)
os.chdir(path)
df = pd.read_csv('master_data_final_sib_camp_col.csv',sep=",")
df.columns

df = pd.read_csv('titanic1.csv')   
df.isnull().sum()
df = call_outlier(df) 
df.isnull().sum()
df.head()
#Removing the camp col
camp_col_name = ['State', 'camp', 'Account Length', 'Area Code', 'Phone']
camp_col_name = ['camp', 'Account Length', 'Area Code', 'Phone']

df = df[df[camp_col_name] == 'c2']
df.drop(camp_col_name, axis = 1, inplace = True)
df.drop('sku', axis = 1, inplace = True)
df.head()
df.isnull().sum()
df = call_outlier(df) 

median(df.loc(1).values)
df
##Remove the Camp column
df.drop('camp', axis = 1, inplace = True)
print(len(df))


"""



        
        
