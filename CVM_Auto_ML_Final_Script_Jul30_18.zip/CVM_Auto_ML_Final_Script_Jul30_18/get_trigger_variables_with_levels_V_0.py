#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 28 11:47:43 2018
Return the list of variable of a given trigger
Argument will be given 
arg1  = dataFrame which contains trigger, level and variables
arg2 = Trigger Name
arg3 = Level of the Trigger
exa
get_var_trigger(df, 'trigger3', 1)
@author: kamran
"""

# Suite to get the variable list of each trigger
def get_var_trigger(df, trigger_name, level):
    """#This suit return the variable name store against the "trigger_name"
    # Level 1 return variable where level 1 is their cell
    # Level 2 return level1 as well as level2 varibales
    # Else return all the variable"""
    if int(level) == 1:
        return df[df[trigger_name]== level]['Variable']
    elif int(level) == 2:
        df2 = df
        df = df[df[trigger_name] == level]['Variable']
        df2 = df2[df2[trigger_name] == level - 1]["Variable"]
        df = df.append(df2, ignore_index = False)
        return df
    elif int(level) == 3:
        """
        return df['Variable']
        """
        df2 = df
        df3 = df
        #Level 3 features
        df = df[df[trigger_name] == level]['Variable']
        #Level 2 features
        df2 = df2[df2[trigger_name] == level - 1]["Variable"]
        #Level 1 features
        df3 = df3[df3[trigger_name] == level - 2]["Variable"]
        #Append all the level features
        df = df.append(df2, ignore_index = False)
        df = df.append(df3, ignore_index = False)
        return df
    
    else:
        return df[df[trigger_name]== 1]['Variable']
        