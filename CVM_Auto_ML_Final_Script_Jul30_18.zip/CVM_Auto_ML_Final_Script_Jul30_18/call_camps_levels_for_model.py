#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  7 14:17:14 2018
This module does the following things
-> Find the Camps along with its levels on which model creation
is going to happen
->Has 3 Arguments. i.e 1."Camp_count" as DataFrame, 2. "Model_Status", as DataFrame
    3. "var_limit", as DataFrame(Contains Camp, Level and its Value)  
-> Return a Dictonary like this
{'c1': [2], 'c4': [1, 2, 3]}
c1 and c4 are camps and 1,2,3 are its level
@author: kamran
"""
import pandas as pd

def camp_levels_for_model(camp_count,model_status,sample_size):
    #First set the column of model_status as "camp"
    model_status.set_index('camp', inplace=True)
    #First set the column of model_status as "camp"
    sample_size.set_index('camp', inplace=True) 
    final_call = pd.DataFrame(columns=['camp','level'])
    
    for index, row in camp_count.iterrows():    
        for camp, level in model_status.iterrows():
            if row["camp"] == camp:
                #print('outer loop', camp)
                for i in range(0,len(level)):
                    #print(level[i], camp)
                    if level[i] == 'done':
                        break
                    elif level[i] == 'fail':
                        i  += 1
                    elif level[i] == 'nd':
                #else:
                    #print( i+1, camp)
                    #print('middle_loop',camp)
                    #print("level"+str(i+1), camp)
                        for cc1, ll1 in sample_size.iterrows():
                            if cc1 == camp:
                                #print(cc1, "level"+str(i+1), ll1[i])
                                if row['count'] >= ll1[i]:
                                    #print(cc1, "level"+str(i+1), ll1[i])
                                    #final_call = final_call.append({'camp': cc1, 'level': "level"+str(i+1)}, ignore_index=True)
                                    final_call = final_call.append({'camp': cc1, 'level': i+1}, ignore_index=True)
                                
                            #print()
                            #for i in range(0, len(ll1)):
                                #print("level"+str(i+1), camp)
                                #if "level"+str(i+1) == 
                    
    final_call_camp_levels = dict()
    for index, row in final_call.iterrows():
        if row['camp'] in final_call_camp_levels:
            # append the new number to the existing array at this slot
            final_call_camp_levels[row['camp']].append(row['level'])
        else:
            # create a new array in this slot
            final_call_camp_levels[row['camp']] = [row['level']]               
    return final_call_camp_levels                            
#print(final_call)                    

#Testing Part
#load the data set 
"""
import os
os.chdir('/home/kamran/Link to CVM/AutoML/Final_concept')
camp_count = pd.read_csv('camp_count.csv')
model_status = pd.read_csv('model_status.csv',index_col= False)
sample_size = pd.read_csv('var_limit.csv')
a = camp_levels_for_model(camp_count,model_status,sample_size)
#Output is
{'c1': [2, 3], 'c4': [1, 2, 3]}

"""


