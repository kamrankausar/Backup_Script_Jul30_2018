#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 28 14:53:58 2018

@author: kamran
"""

#Define the Global variables

#def cvm_auto_ml():
###################Loading the In-Built Module#################################
import os
import pandas as pd
import time
# Import the H2O 
#import h2o
#import os
#from h2o import import_file, H2OFrame
#from h2o.automl import H2OAutoML
#h2o.init()

#import time

#You can safely disable this new warning with the following assignment.
pd.options.mode.chained_assignment = None  # default='warn'

####################Change the Directory to Load the Module
os.chdir('/media/DATA/CVM/AutoML/poc_product_backorder')



##################Loading the Third Party Module###############################
#@Import the Trigger Count Module
from trigger_count_module import call_trigger_count
#@Import the get Trigger Variable Module
from get_trigger_variables_with_levels_V_0 import get_var_trigger

#Import the Block1 Module i.e Camp and its level on which model is 
#going to build
from call_camps_levels_for_model import camp_levels_for_model

#call the model creation module
from model_creation_flag import model_creation

#Calling the OutLier Module
from outlier_detect_replace_nan_jun_29 import call_outlier

#------------------------------------------------------------------------------
#Calling the Missing Value Module
#Part 0(remove features) and Part 1(knn_impute)
#Self written module for remove the column which has greater than 20% missing value
#and then impute the missing with KNN
from missing_part0_remove_part1_knn import missing_remove_knn

#Part 2
#Self written module for doing simple missing value imputation 
#for cat = mode and numeric = median
from data_frame_imputer_simple import DataFrameImputerSimple
#Note module will be call according to order i.e Part0_1 first then Part2 last
#------------------------------------------------------------------------------
#OverSampling and build the model and save that
from over_sampling_ml_build_saving import imbal_over_sam
from over_sampling_ml_build_saving import over_sample_build_save_model

#------------------------------------------------------------------------------

"""
##################Change the Directory Where the module is present#######################################
os.chdir('/home/kamran/Link to CVM/AutoML/Test_Part/test_data_for_poc0')
# Read the Champaign file
camp_data = pd.read_csv('camp_data.csv')
#Load the Trigger Variable Master List
df_trigger_var = pd.read_csv('master_var_list_test.csv')
#Load the Master Data File
"""
    
#####################Step1##########################################
#@Install the Module
#Importing the Auto Install Module
from install_module_auto import call_install_module
#Caling the Auto Install module
print("Loading the Module")
call_install_module()
print('Done with Loading Module')

##################Loading the Data Files#######################################
os.chdir('/media/DATA/CVM/AutoML/poc_product_backorder')
# Read the Champaign file
camp_data = pd.read_csv('camp_table_pb.csv')
#Load the Trigger Variable Master List
df_trigger_var = pd.read_csv('master_var_list_pb.csv')
#print(df_trigger_var)
#Load the Master Data File
#from master_script_v0_poc import call_data_prepare

#df = pd.read_csv('master_data_final_pb.csv')
#df.head()
####################Step2#######################################
#Calling the Trigger Count Module
#Note call_trigger_count takes these two argumnts
#Arg1 = dataFrame containg the Triggers data
#Arg2 = Count(BMT)
#Return like this 
#if Trigger pass the BMT(count = 4) then return will be a list like 
#[1, final_trigger_to_call]
#esle [0]
print('Trigger Count Steps...')
trigger_count = call_trigger_count(camp_data, 500)
print(trigger_count)
"""
print(trigger_count[0])
print(trigger_count[1])
print(trigger_count[0] == 1)
"""
#Load the Dataset
model_status = pd.read_csv('model_status.csv')
sample_size  = pd.read_csv('var_limit.csv')

#call_camp_level = camp_levels_for_model(camp_count,model_status,sample_size)
#Global Variable
f1_bmt = 60
primary_keys = "sku"
target_feature = "went_on_backorder"
model_count = 1
percent_over_sample = 30




#Checking the Trigger Count
if len(str(trigger_count)) != 1:
    trigger_count = pd.DataFrame(trigger_count)
    print("The Triggers are", trigger_count)
    #trigger_list = trigger_count[1]
    #print('Trigger List Pass the BMT...')
    
    final_call_camp_levels = camp_levels_for_model(trigger_count,model_status,sample_size)

#################@Step4: Call Trigger Variable#################################
    if len(final_call_camp_levels) != 0:
        print('Get the Variable of the Each Trigger...')
        #levels = [1,2,3]
        #for key in final_call_camp_levels:
        #for value in final_call_camp_levels[key]:
        for key in final_call_camp_levels:
                print("Trigger Name \n", key)
                for value in final_call_camp_levels[key]:
                    print("Trigger Name \n", key)
                    print('Level of the Trigger\n', value)
                    var_list = get_var_trigger(df_trigger_var, key, value)
                #print(var_list)
###############@Step5: Get the Data for the Trigger Variable###################
                #var_list = list(var_list)
                    print(var_list)
                    var_list = list(var_list)
                    #Checking "var_list" column is in data column or not 
                    #Remove columns which is in "var_list" and not in data columns
                    #Get all the column of master data file
                    data_col = pd.read_csv('master_data_final_pb.csv', nrows = 1).columns.tolist()
                    final_col = list(set(var_list).intersection(data_col))
                    #Done with Removing col name
                    df = pd.read_csv('master_data_final_pb.csv',sep=",", usecols=final_col ,skipinitialspace=True,infer_datetime_format=False, low_memory=False)
                    #df = pd.read_csv('master_data_final_pb.csv')
                    #data = pd.read_csv('data.csv',sep=",", usecols=list(var_list[var_list!='nan']) ,skipinitialspace=True,infer_datetime_format=False, low_memory=False)
                    #data = pd.read_csv('data.csv',sep="\s*\,\s*", usecols=list(var_list ))
                    #data = pd.read_csv('data.csv',sep=",", usecols=list(var_list ))
                    df.dropna(axis = 1, how = 'all', inplace = True)
                    print('Model Creation for Camp:- {0} with Level{1} '.format(key, value))
                    #print(data)
                    #----------------------------------------------------------
                    #Calling outlier Module
                    print("\nOutlier Detection and Handling...")
                    df = call_outlier(df)
                    #----------------------------------------------------------
                    #Calling Missimg value Modules one by one order must be maintain
                    print("\nMissing Value Imputation...")
                    #df = missing_remove_knn(df)
                    df = DataFrameImputerSimple().fit_transform(df)
                    #----------------------------------------------------------
                    
                    model_flag = model_creation(df, key, f1_bmt, primary_keys, target_feature, model_count)
                    """
                    print("Trying OverSampling....")
                        #See modules for more details
                        df_list = imbal_over_sam(df, primary_keys, target_feature, percent_over_sample)
                        bmt_f1-build_model = over_sample_build_save_model(df_list[0], df_list[1], target_feature, f1_bmt, key, model_count)
                    
                    """
                    if model_flag[0]:
                        print("Model Build Successfully with F1 Score is:-", model_flag[1])
                        
                        #value is only integer so concatenate 'level' with value i.e level1
                        level = 'level'+str(value)
                        #print('Camp-',key, 'Level is-',level )
                        #print('Updating the Camp:- {0} and Level:- {1} '.format(key, value))
                        #model_status.set_index('camp', inplace = True)
                        print(model_status)
                        print('Updating the Camp:- {0} and Level:- {1} '.format(key, value))
                        time.sleep(5)
                        #update for particular camp and its level
                        model_status.at[key, level] = 'done'
                        print(model_status)
                        #model_status.reset_index(inplace = True)
                        #print('Updating the Camp:- {0} and Level:- {1} '.format(key, level))
                        model_status.to_csv('model_status.csv')
                        time.sleep(5)
                        print('Update Successfully for Camp:- {0} and Level:- {1} '.format(key, level))
                        
                        #Update the table of Model Status
                        break
                    else:
                        print("Model not Build, because F1 Score is:- ", model_flag[1])
                        #print('Updating the Camp:- {0} and Level{1} '.format(key, value))
                        print("\n")
                        #value is only integer so concatenate 'level' with value i.e level1
                        level = 'level'+str(value)
                        print('Camp-',key, 'Level is-',level )
                        #print('Updating the Camp:- {0} and Level:- {1} '.format(key, value))
                        #model_status.set_index('camp', inplace = True)
                        print(model_status)
                        time.sleep(5)
                        #update for particular camp and its level
                        model_status.at[key, level] = 'fail'
                        print('Updating the Camp:- {0} and Level:- {1} '.format(key, level))
                        print(model_status)
                        #model_status.reset_index(inplace = True)
                        
                        model_status.to_csv('model_status.csv')
                        time.sleep(5)
                        print('Update Successfully for Camp:- {0} and Level:- {1} '.format(key, level))
                        #Update the table of Model Status
                        #model_status[model_status.camp == key].loc[0][value] = 'fail'
                        time.sleep(5)
                        pass
                        #Test Part
                        #df1 = H2OFrame(data)
                        #y = "camp_response"
                        #x = df1.columns
                        #x.remove(y)
                        #x.remove('Customer_ID')
                        #n = 15
                        #aml = H2OAutoML(max_models = n, nfolds=3, stopping_metric='misclassification' ,seed = 1)
                        #aml.train(x = x, y = y, training_frame = df1)
                        #lb = aml.leaderboard
                        #print(lb.head(n))
                        
                        #Test Part End
            #print('Benchmark not met. So, go for Next Level')

        
    else:
        print('No any Camp to build the Model')
    
           #time.sleep(10)
else:
    #Triggers not pass the BMT(Count)    
    print('No Camp Passes the BMT(count = 500)')


    