#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 29 12:04:27 2018

@author: kamran
"""
import pandas as pd
import numpy as np

#For ignore the pandas warning
pd.options.mode.chained_assignment = None  # default='warn'
#For np warning run time
np.warnings.filterwarnings('ignore')

def is_outlier(column, thresh=4.0):
    """
    Returns a boolean array with True if points are outliers and False 
    otherwise.

    Parameters:
    -----------
        column: An numerical observations by num dimensions array of observations
        thresh : The modified z-score to use as a threshold. Observations with
            a modified z-score (based on the median absolute deviation) greater
            than this value will be classified as outliers.

    Returns:
    --------
        mask : A numerical observations-length boolean array.

    References:
    ----------
        Boris Iglewicz and David Hoaglin (1993), "Volume 16: How to Detect and
        Handle Outliers", The ASQC Basic References in Quality Control:
        Statistical Techniques, Edward F. Mykytka, Ph.D., Editor. 
    """
    if len(column.shape) == 1:
        column = column[:,None]
        #np.nanmedian(a)
    median = np.nanmedian(column, axis=0)
    diff = np.sum((column - median)**2, axis=-1)
    diff = np.sqrt(diff)
    med_abs_deviation = np.nanmedian(diff)

    modified_z_score = 0.6745 * diff / med_abs_deviation
        #if modified_z_score > thresh:
        

    return modified_z_score > thresh

# call_outlier is actuall function to call
# Taking df as argument and returning df with replacing outlier with nan
    

def call_outlier(df):
    for i in list(df.columns):
    #print(type((df[i][0])))
    #Checking if it is not string and unique values are not less than 10 for 
    # factor like features
        if not isinstance(df[i][1], str) and df[i].nunique() >= 10:
        #pass
            df[i][is_outlier(df[i].values)] = np.nan
        #print("It is a Integer:- ", i)
        #print(i)
        else:
            pass
        #df[i][is_outlier(df[i].values)] = np.nan
        #print('\nIt is  a String:-', i)
        #print(i)
        
        
    return df


#Testing Part
"""
df = pd.read_csv('titanic1.csv')   
df.isnull().sum()
df = call_outlier(df) 
df.isnull().sum()
"""



        
        
