#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 13 11:47:46 2018

@author: kamran
"""
#Importing the Module
import pandas as pd # For handling Pandas data Frame
#For Test and train split
from sklearn.model_selection import train_test_split
#For OverSampling 
#Module for resampling	
from sklearn.utils import resample

#df = pd.read_csv('product_backorders.csv')

#For Rename
import os

#For testing Purpose only
"""
percent_over_sample = 30
target_feature = 'went_on_backorder'
model_count = 3
primary_keys ='sku'
target = 'went_on_backorder'
trigger_name_level = 'Trigger1'
bmt_f1 = .60

"""

def imbal_over_sam(df, primary_keys, target_feature, percent_over_sample = 30):
    ###########################################################################
    #This Suite is doing these jobs:
    # 1. Taking imbalance data Frame then 
    # 2. Split into train and test
    # 3. On Train, find target class proportion
    # 4. Over sample the minority class by "per_over_sample" i.e percentage of 
    # majority class
    # Return the Pandas DataFrame train and test after the balancing
    #Parameter
    #____________________________
    #1. df - Imbalance Pandas Data Frame
    #2. percent_over_sample - Percentage to oversample the minority class
    #Return
    #_________________
    #train - Pandas Data Frame
    #Test - Pandas Data Frame
    ###########################################################################
    
    ##Global Variable Space
    
    percent_over_sample = percent_over_sample
    minoritory_new_sample_size  = int()
    
    ##Droping the useless columns
    #df.drop(primary_keys, axis = 1, inplace = True)
    
    ##Checking the Imbalance
    target = target_feature
    target_count = df[target].value_counts()
    
    ##Imbalance Proportion
    imba_prop = round(target_count[0] / target_count[1], 2)
    
    ##Spliting the dataFrame into train and test
    train, test = train_test_split(df, test_size=0.2, random_state = 1)
    
    ## Separate majority and minority classes
    ## No are the people who are loan defaulter
    df_majority = train[train[target]=='No']
    df_minority = train[train[target]=='Yes']
    
    ##New count of minority class on the basis of majority class count and percentage given
    minority_new_sample_size = round((int(percent_over_sample)/100) * len(train[train[target]=='No'] ))
    minority_new_sample_size
    
    ##Calling the Sample Module
    ## Upsample minority class
    df_minority_upsampled = resample(df_minority, 
                                     replace = True,     # sample with replacement
                                     n_samples = minority_new_sample_size,    # to match majority class
                                     random_state = 123) # reproducible results
    
    ## Combine majority class with upsampled minority class
    train = pd.concat([df_majority, df_minority_upsampled])
    
    ##Returning part
    return [train,test]


def over_sample_build_save_model(train, test, target_feature, f1_bmt, key, model_count = 3):
    ###########################################################################
    #This Suite is doing following jobs
    #1. Take the oversample pandas data Frame i.e train and convert into h2O data frame
    #2. Same for test pandas data frame
    #3. Build The model
    #4. Check the F1 score 
    #5. If passes the BMT(Bench Mark Test) then go for Saving model 
    #6. That's All till now
    #
    #Parameter
    #__________________________________________________________________________
    #1. train - Pandas data Frame
    #2. test - Pandas data Frame
    #3. bmt_f1 - F1 score to check
    #4. trigger_name_level - Name of the trigger and its level
    #5. target_feature -  Name of the Dependent Variable
    #6. model_count - Max  Algo to try
    ##Return Part
    #1. f1_score - Value
    #2. build_model - Flag(Yes/No)
    #3.  
    ###########
    #Update the request module
    #!pip3 install --upgrade requests
    ##Importing Module
    import h2o
    from h2o.automl import H2OAutoML
    from h2o import  H2OFrame #For converting Pandas DataFrame to H2O DataFrame
    h2o.init()
    
    ##Convert Pandas DataFrame into H2O dataFrame
    train = H2OFrame(train)
    test = H2OFrame(test)
    y = target_feature
    x = train.columns
    x.remove(y)
    trigger_name_level = key
    #x.remove('sku')
    
    ##Building the Model starts
    aml = H2OAutoML(max_models = model_count, seed = 1)
    aml.train(x = x, y = y, training_frame = train, validation_frame = test)
    #aml.leader.balance_classes = True
    model = aml.leader
    #model.balance_classes()
    ##Geting F1 Score
    f1_score = model.F1(valid=True)[0]#Get the sublist i.e [[0.6037680411330087, 0.9380530973451328]] to [0.6037680411330087, 0.9380530973451328]
    f1_score = f1_score[1] #Get the F1_score
    f1_score = round(f1_score,2) #Round the F1_Score to 2 decimal place
    
    ##Geting F1 Score Threshold
    f1_score_thres_raw = model.F1(valid=True)[0] #Get the sublist i.e [[0.6037680411330087, 0.9380530973451328]] to [0.6037680411330087, 0.9380530973451328]
    f1_score_thres = f1_score_thres_raw[0] #Get the threshold 
    f1_score_thres = round(f1_score_thres,2) #Round the threshold to 2 decimal places
    
    ##Getting Accuracy
    accuracy_score = model.accuracy(valid=True)[0][1] #Contains like this [[threshold,accuracy]]
    #accuracy_score = accuracy_score[1]
    accuracy_score = round(accuracy_score,2)
    
    ##Getting AUC
    auc_score = model.auc(valid = True) #Only contain one value i.e float
    #auc_score = auc_score
    auc_score = round(auc_score,2)
    
    ##Getting Confusion Matrix
    cm_f1_score = model.confusion_matrix(metrics="f1", valid=True)
    
    #f1_score *= 100
    f1_bmt = float(f1_bmt/100)
    
    ##Checking the F1 Score
    if f1_score >= f1_bmt:
        #bmt_pass = True
        ## save the model
        #h2o.save_model(aml.leader, path = "/media/DATA/CVM/AutoML/spliting_balancing", force = True)
        #h2o.download_mojo(aml.leader, path = "/media/DATA/CVM/AutoML/spliting_balancing", force = True)
        #modelfile = model.download_mojo(path="/media/DATA/CVM/AutoML/spliting_balancing", get_genmodel_jar=True)
        #path=".", get_genmodel_jar=False, genmodel_name=""
        
        ##Postfix the .zip to the trigger name
        trigger_name_level = trigger_name_level + '.zip'
        
        ##Download the MOJO model
        #modelfile = model.download_mojo(path="/media/DATA/CVM/AutoML/spliting_balancing", get_genmodel_jar=True, genmodel_name=trigger_name_level)
        modelfile = model.download_mojo(path="/media/DATA/CVM/AutoML/poc_product_backorder", get_genmodel_jar=False, genmodel_name='kk')
        print("Model saved to " + modelfile)
        ##Rename the Model
        old_name = modelfile.split("/")[-1]
        try:
            os.rename(old_name, trigger_name_level)
            ##Change the build_model Flag if Model is downloaded
            build_model = "Yes"
        except:
            build_model = "No"
        #pass
    else:
        #bmt_pass = "No"
        build_model = "No"
    
    ##Returning Part    [0, 1, 2, 3, 4, 5]
    return [build_model,f1_score,f1_score_thres,accuracy_score,auc_score, cm_f1_score ]
        
        
        
    
"""    
#Testing Part
import sys
a = imbal_over_sam(df, primary_keys, target_feature, percent_over_sample = 30)
flag_bundle = over_sample_build_save_model(a[0], a[1], target_feature, bmt_f1, trigger_name_level, model_count = 3)


sys.getsizeof(a[0])
sys.getsizeof(a[1])
type(a)
a[0]
""" 

  
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    