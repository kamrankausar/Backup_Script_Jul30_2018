#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 12:35:19 2018

@author: kamran
"""

#Self written KNN_Impute module
from knn_impute import knn_impute
import pandas as pd

#You can safely disable this new warning with the following assignment.
pd.options.mode.chained_assignment = None  # default='warn'




def missing_remove_knn(df, per_miss_remove_limit = 0.20):
    #Remove the features if it has greater than 20% missing
    pct_null = df.isnull().sum() / len(df) 
    missing_features = pct_null[pct_null > per_miss_remove_limit].index
    df.drop(missing_features, axis=1, inplace=True)
    #return df
    #Call for knn_impute 
    for i in list(df.columns):
    #print(type((df[i][0])))
        if round(df[i].isnull().sum() / df.shape[0], 2) * 100 >= 7:
            if isinstance(df[i].iloc[0], str):
                #print("It is String")
                #print(i)
                df[i] = knn_impute(target=df[i], attributes=df.drop([i], 1),
                                    aggregation_method="mode", k_neighbors=10, numeric_distance='euclidean',
                                    categorical_distance='hamming', missing_neighbors_threshold=0.8)        
            else:
                #print('Not a String')
                #print(i)
                df[i] = knn_impute(target=df[i], attributes=df.drop([i], 1),
                                    aggregation_method="median", k_neighbors=10, numeric_distance='euclidean',
                                    categorical_distance='hamming', missing_neighbors_threshold=0.8)
        else: pass
    
    return df


#Testing Part
"""
df = pd.read_csv('titanic1.csv') 
df = missing_remove_knn(df) 
df.isnull().sum()  
df.columns    
"""    

    