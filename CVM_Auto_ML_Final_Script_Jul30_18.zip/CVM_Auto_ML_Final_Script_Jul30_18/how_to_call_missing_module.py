#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 17:06:02 2018

@author: kamran
"""
#Part 0(remove features) and Part 1(knn_impute)
#Self written module for remove the column which has greater than 20% missing value
#and then impute the missing with KNN
from missing_part0_remove_part1_knn import missing_remove_knn

#Part 2
#Self written module for doing simple missing value imputation 
#for cat = mode and numeric = median
from data_frame_imputer_simple import DataFrameImputerSimple

#Note module will be call according to order i.e Part0_1 first then Part2 last

import pandas as pd
df = pd.read_csv('titanic1.csv') 
df = pd.read_csv('master_data_final_pb.csv') 
df = missing_remove_knn(df) 
df.isnull().sum()  
df.columns  
df = DataFrameImputerSimple().fit_transform(df)
df.isnull().sum()  

