#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 28 14:19:26 2018
How to use
Write below lines in the Master Script i.e cvm_auto_ml()
from install_module_auto import call_install_module
call_install_module()
@author: kamran
"""

    
#Call this module in the Master Script
def auto_install_module():
    print('Importing OS module')
    import os
    
    #checking for pip module
    try:
        print('Importing PIP module')
        import pip
    except ImportError:
        print("Trying to install required module: pip\n")
        # import the os package to install pip module if not install
        os.system('python -m pip install pip')
        import pip
    
    #Self generated Suite to install modules
    def install_module(module):
        pip.main(['install', module])
    #Checking for each library and install it if necessary
    try:
        print('Importing Pandas module as pd')
        import pandas as pd
    except ImportError:
        print('Trying to install required module: pandas')        
        install_module('pandas')
        import pandas as pd
    # For time package
    try:
        print('Importing Time module')
        import time
    except ImportError:
        print('Trying to install required module: time')
        install_module('time')
        import time
    # For Numpy
    try:
        print('Importing Numpy module')
        import numpy as np
    except ImportError:
        print('Trying to install required module: time')
        install_module('numpy')
        import numpy as np

def call_install_module():
    auto_install_module()        
    