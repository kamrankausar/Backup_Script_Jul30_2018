#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 11:54:53 2018

@author: kamran
"""

import pandas as pd
import numpy as np
from sklearn.base import TransformerMixin

class DataFrameImputerSimple(TransformerMixin):

    def __init__(self):
        """Impute missing values.

        Columns of dtype object are imputed with the most frequent value 
        in column.

        Columns of other types are imputed with mean of column.

        """
    def fit(self, X, y=None):

        self.fill = pd.Series([X[c].value_counts().index[0]
            if X[c].dtype == np.dtype('O') else X[c].median() for c in X],
            index=X.columns)

        return self

    def transform(self, X, y=None):
        return X.fillna(self.fill)
    
    
"""
How to use
"from data_frame_imputer_simple import DataFrameImputerSimple"
"X1 = DataFrameImputerSimple().fit_transform(X1)"
"""


    
    
