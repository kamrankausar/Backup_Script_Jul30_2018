#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 19 17:00:17 2018

@author: kamran
"""

from missing_part0_remove_part1_knn import missing_remove_knn

#Part 2
#Self written module for doing simple missing value imputation 
#for cat = mode and numeric = median
from data_frame_imputer_simple import DataFrameImputerSimple

import pandas as pd

def miss_call(df):
    df = missing_remove_knn(df) 
    #df = DataFrameImputerSimple().fit_transform(df)
    return df


df = pd.read_csv('master_data_final_pb.csv')

df = miss_call(df)
df.isnull().sum()
