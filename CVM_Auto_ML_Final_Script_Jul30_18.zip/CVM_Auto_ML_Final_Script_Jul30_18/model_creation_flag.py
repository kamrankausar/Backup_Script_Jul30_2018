#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 11 09:44:47 2018
#This suite takes the DataFrame as argument and Build the Model using H2O 
# And Return the Flage i.e 1 for Model pass the Bemch Mark Test 
return [flag, f1_score, accuracy_score,auc_score, cm_f1_score]
# 0 for not pass the bench mark test 
#Parameter of the Suit
model_creation(df,key, f1_bmt, primary_keys, target_feature, model_count)
@author: kamran
"""

import pandas as pd
import os
#from h2o.automl import H2OAutoML
#import h2o
#os.chdir("/home/kamran/Link to CVM/AutoML/Final_concept/Test_data_set")
#df = pd.read_csv('product_backorders.csv')

import h2o
from h2o import  H2OFrame
from h2o.automl import H2OAutoML
h2o.init()



#For Testing End

def model_creation(df,key, f1_bmt, primary_keys, target_feature, model_count):
    trigger_name = key
    f1_bmt = float(f1_bmt/100)
    df = H2OFrame(df)
    y = target_feature
    x = df.columns
    x.remove(y)
    #x.remove(primary_keys)
    aml = H2OAutoML(max_models = 1, seed = 1)
    aml.train(x = x, y = y, training_frame = df)
    leader_top = aml.leaderboard.as_data_frame()
    top_auc = leader_top[['auc']]
    #print(auc)
    top_logloss = leader_top[['logloss']]
    top_auc = pd.to_numeric(top_auc['auc'], errors='coerce', downcast='float')
    top_logloss = pd.to_numeric(leader_top['logloss'], errors = 'coerce', downcast='float')
    top_auc = top_auc[0]
    top_logloss = top_logloss[0]
    
    ##Geting F1 Score
    model = aml.leader
    f1_score = model.F1(valid=True)[0][1] #Contains like this [[threshold,F1 score]]
    #f1_score = f1_score[1]
    f1_score = round(f1_score,2)
    ##Get the F1_Score Threshold
    f1_score_thres = model.F1(valid=True)[0][0]
    f1_score_thres = round(f1_score_thres,2)
    
    ##Getting Accuracy
    accuracy_score = model.accuracy(valid=True)[0][1] #Contains like this [[threshold,accuracy]]
    #accuracy_score = accuracy_score[1]
    accuracy_score = round(accuracy_score,2)
    
    ##Getting AUC
    auc_score = model.auc(valid = True) #Only contain one value i.e float
    #auc_score = auc_score
    auc_score = round(auc_score,2)
    
    ##Getting Confusion Matrix
    cm_f1_score = model.confusion_matrix(metrics="f1", valid=True)
    
    
    
    
    if f1_score >= f1_bmt:
        #Postfix the .zip to the trigger name
        trigger_name = trigger_name + '.zip'
        #Download the MOJO model
        #modelfile = model.download_mojo(path="/media/DATA/CVM/AutoML/spliting_balancing", get_genmodel_jar=True, genmodel_name=trigger_name_level)
        modelfile = model.download_mojo(path="/media/DATA/CVM/AutoML/poc_product_backorder", get_genmodel_jar=False, genmodel_name='kk')
        print("Model saved to " + modelfile)
        old_name = modelfile.split("/")[-1]
        try:
            os.rename(old_name, trigger_name)
            flag = "Yes"
        except:
            flag = "No"
    else: flag = "No"
    return [flag, f1_score, f1_score_thres, accuracy_score,auc_score, cm_f1_score] 

#For Testing
#To Call the Suite
#model_test = model_creation(df)
#print(model_test) 
   
