#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 28 15:37:16 2018

This Module count the frequencies of the each of the Triggers
How is this module work
Aguments 
Two argument ie. 
Arg1 = DataFrame which contain the triggers and test on column 'Trigger'
Arg2 = Count (BMT)
Return Type
if Trigger pass the BMT(count = 4) then return will be a list like 
    [1, final_trigger_to_call]
esle 
    [0]
@author: kamran
"""
import pandas as pd
import numpy as np
#You can safely disable this new warning with the following assignment.
pd.options.mode.chained_assignment = None  # default='warn'

def call_trigger_count(df, count):
    #Checking the count of the each of the triggers and convert into the DataFrame
    #final_trigger_to_call = pd.DataFrame(df['Trigger_Name'].value_counts())
    #final_trigger_to_call = list(final_trigger_to_call[final_trigger_to_call['Trigger_Name'] >= count].index)
    df['count'] = np.zeros
    df = df.groupby('Trigger_Name').count().reset_index()[['Trigger_Name', 'count']]
    df = df[df['count'] >= count]
    # Rename the Columns
    df.rename(columns={'Trigger_Name':'camp'}, inplace = True)
    if len(df) != 0:
        return df
    else :return 0
    
    


#Test Part
"""    
import os
os.chdir('/media/DATA/CVM/AutoML/poc_product_backorder')
count = 200

df = pd.read_csv('camp_table_pb.csv')

a = call_trigger_count(df, count)
a[1]

df['count'] = np.zeros
df_return = df.groupby('Trigger_Name').count().reset_index()[['Trigger_Name', 'count']]

df_return[df_return['count'] >= count]
"""
#Test Part End